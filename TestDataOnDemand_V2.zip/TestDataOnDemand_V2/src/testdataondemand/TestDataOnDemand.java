/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testdataondemand;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.*;
import java.awt.*;
import java.util.jar.Attributes;
import javax.swing.table.TableColumn;
import net.proteanit.sql.DbUtils;

/**
 *
 * @author C47609
 */
public class TestDataOnDemand {

    /**
     * @param args the command line arguments
     */
    
    public static Connection DbCon() {
   Connection conn = null; 
   ResultSet rs = null;
   PreparedStatement pst = null;
               try { 
   String driver = "oracle.jdbc.driver.OracleDriver";
   
   /* String driver = "org.apache.derby.jdbc.ClientDriver";  */
  
         Class.forName(driver);
String login = "jdbc:oracle:thin:@//DBDNL23-scan.nl.eu.abnamro.com:1521/sts.a.de.a2.grid";
   
 /*   String login = "jdbc:derby://localhost:1527/TDM";*/
      /*  conn = DriverManager.getConnection(login,"TDM","123");*/
      
    conn = DriverManager.getConnection(login,"GTREP","Aqwsc#10");
      //JOptionPane.showMessageDialog(null," Database Connected");
            System.out.print("Connected");
                 return conn;
   
   } catch (Exception ex){
   System.out.println("Error: " + ex);
   JOptionPane.showMessageDialog(null,ex);
   return null;
   
   }
     
    }
    
    public static Connection DbCon2() {
   Connection conn = null; 
   ResultSet rs = null;
   PreparedStatement pst = null;
               try {   
    /*String driver = "oracle.jdbc.driver.OracleDriver";*/
    String driver = "com.ibm.db2.jcc.DB2Driver";                    
         Class.forName(driver);
   /* String login = "jdbc:oracle:thin:@localhost:1521:XE";*/
   //jdbc:db2://u390tt1.ao.nl.abnamro.com:5010/NLAABDB2DBT1
//   ST connection details :
   String login = "jdbc:db2://u390tt1.ao.nl.abnamro.com:5010/NLAABDB2DBT1";
      conn = DriverManager.getConnection(login,"C47609","access22");
 // ET CONNECTION DETAILS :
//String login = "jdbc:db2://u390ac1.ao.nl.abnamro.com:5025/NLAABDB2DBXC";
//   conn = DriverManager.getConnection(login,"U@MUXJ2","wrleeu34");
      //JOptionPane.showMessageDialog(null," Database Connected");
            System.out.print("Connected");
                 return conn;
   
   } catch (Exception ex){
   System.out.println("Error: " + ex);
   JOptionPane.showMessageDialog(null,ex);
   return null;
   
   }
     
    }
    
    public static void main(String[] args) {
        // TODO code application logic here
        
        TestDataOnDemand Db1 = new TestDataOnDemand();
            Db1.DbCon();
            
            TestDataOnDemandF1 log = new TestDataOnDemandF1();
          //  Condition log = new Condition();
                    log.setVisible(true);
          
        }
    
}
