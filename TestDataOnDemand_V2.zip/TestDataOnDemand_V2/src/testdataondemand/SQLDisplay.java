/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testdataondemand;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import net.proteanit.sql.DbUtils;
import java.util.*;
/**
 *
 * @author C47609
 */
public class SQLDisplay extends javax.swing.JFrame {
   Connection conn= null; 
   ResultSet rs = null;
   PreparedStatement pst = null;
    /**
     * Creates new form SQLDisplay
     */
    public SQLDisplay() {
        initComponents();
        conn=TestDataOnDemand.DbCon();
       // List data = new ArrayList();
          
    }

    public void doSomething (TestDataOnDemandF1 DPSQL){
     //JOptionPane.showMessageDialog(null, DPSQL.getName());   
             try
     {               
String sql = "SELECT DISTINCT A.SQLSELECT,A.SQLFROM,A.SQLWHERE FROM TDM.TDMSQLTABLE A"
     + ",TDM.TESTCASETABLE B WHERE A.KEY1= B.SQLKEY "
     + " ORDER BY A.SQLWHERE ASC ";
     pst =conn.prepareStatement(sql);
     rs= pst.executeQuery();
     System.err.println(""+rs); 
       

     Table2.setModel(DbUtils.resultSetToTableModel(rs));
     /*****************************************************/
     try {                      
        File file = new File("\\solon.prd\\branches\\P\\Global\\Users\\"
                + "C47609\\Userdata\\Desktop\\GeneratedSql.sql");
         if (!file.exists()) {
             file.createNewFile();
         }
         FileWriter fw = new FileWriter(file.getAbsoluteFile());
         BufferedWriter bw = new BufferedWriter(fw);
        /* bw.write("                                          "
                 + "                                        "); 
            bw.newLine();
         bw.write("                                                    "); 
            bw.newLine();*/
                
       for (int i=0;i<Table2.getRowCount();i++){
          // for (int j=0;j<Table2.getColumnCount();j++){
          for (int j=0;j<1;j++){
            if (i==0)
            {  
                bw.write("Select"); 
              //  bw.newLine();
            } 
            bw.write("            "+ Table2.getModel().getValueAt(i,j)+" "+" ");
          //  bw.newLine();
                    }  
       }
          bw.write("From"); 
        //  bw.newLine();
          
          
          for (int i=0;i<Table2.getRowCount();i++){
          for (int j=1;j<2;j++){
            
            bw.write("      "+ Table2.getModel().getValueAt(i,j)+" "+" ");
         //   bw.newLine();
                    }  
       }
          bw.write("Where"); 
        //  bw.newLine();
       
        for (int i=0;i<Table2.getRowCount();i++){
          for (int j=2;j<3;j++){
            bw.write("      "+ Table2.getModel().getValueAt(i,j)+" "+" ");
         //   bw.newLine();
                    }  
       }
         // bw.write(" ; ");    
     bw.close();
     fw.close();
     }
     catch(Exception e)  {
         JOptionPane.showMessageDialog(null, e);
     }
     
    			     
      }
     catch(Exception e)  {
         JOptionPane.showMessageDialog(null, e);
     }

    finally {
         try{
          
            getData();
          
         }
         catch (Exception e)
         {
        JOptionPane.showMessageDialog(null, e);
            } 
             }
    }           
    
    
    public void getData(){
        try{
    // Open the file that is the first 
    // command line parameter
       conn=TestDataOnDemand.DbCon2();
       
    FileInputStream fstream = new FileInputStream("\\solon.prd\\branches\\P\\Global\\Users\\"
            + "C47609\\Userdata\\Desktop\\GeneratedSql.sql");
        try ( // Get the object of DataInputStream
                DataInputStream in = new DataInputStream(fstream)) {
            BufferedReader br = new BufferedReader(new InputStreamReader(in));
            String strLine;
            //Read File Line By Line
            while ((strLine = br.readLine()) != null) {
                // Print the content on the console
                 
                System.out.println (strLine);
                pst =conn.prepareStatement(strLine);
                rs =pst.executeQuery();
                System.out.println(""+rs);
                Table2.setModel(DbUtils.resultSetToTableModel(rs));
            }
            //Close the input stream
        }
    }catch (Exception e){//Catch exception if any
        System.out.println("<-->");
      System.err.println("Error: " + e.getMessage());
      
      
    }
       
    
    
 }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        bindingGroup = new org.jdesktop.beansbinding.BindingGroup();

        jScrollPane1 = new javax.swing.JScrollPane();
        Table2 = new javax.swing.JTable();

        org.jdesktop.beansbinding.Binding binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, this, org.jdesktop.beansbinding.ObjectProperty.create(), this, org.jdesktop.beansbinding.BeanProperty.create("defaultCloseOperation"));
        bindingGroup.addBinding(binding);

        Table2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(Table2);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 322, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(15, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(14, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 217, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        bindingGroup.bind();

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(SQLDisplay.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(SQLDisplay.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(SQLDisplay.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(SQLDisplay.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new SQLDisplay().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable Table2;
    private javax.swing.JScrollPane jScrollPane1;
    private org.jdesktop.beansbinding.BindingGroup bindingGroup;
    // End of variables declaration//GEN-END:variables
}
